﻿
namespace WingtipToys
{


    public partial class Contact
    {
    }
}
