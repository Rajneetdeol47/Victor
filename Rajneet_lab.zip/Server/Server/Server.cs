﻿using System;
using System.Net.Sockets;
using System.Threading;
public class AsynchIOServer
{
    [Obsolete]
    static TcpListener tcpListener = new TcpListener(10);

    [Obsolete]
    static void Listeners()
    {

        Socket socketForClient = tcpListener.AcceptSocket();
        if (socketForClient.Connected)
        {
            Console.WriteLine("Client:" + socketForClient.RemoteEndPoint + " now connected to server.");
            NetworkStream networkStream = new NetworkStream(socketForClient);
            System.IO.StreamWriter streamWriter =
            new System.IO.StreamWriter(networkStream);
            System.IO.StreamReader streamReader =
            new System.IO.StreamReader(networkStream);


            while (true)
            {
                string theString = streamReader.ReadLine();
                Console.WriteLine("Message recieved from client: " + socketForClient.RemoteEndPoint + " " + theString);
                if (theString == "exit"||theString == "EXIT" || theString == "Exit")
                    break;
            }
            streamReader.Close();
            networkStream.Close();
            streamWriter.Close();

        }
        socketForClient.Close();
        Console.WriteLine("Press any key to exit from server program");
        Console.ReadKey();
        return;
    }

    [Obsolete]
    public static void Main()
    {
        tcpListener.Start();
        Console.WriteLine("This is Server");
        Console.WriteLine("Hoe many clients are going to connect to this server?:");
        int numberOfClientsYouNeedToConnect = int.Parse(Console.ReadLine());
        for (int i = 0; i < numberOfClientsYouNeedToConnect; i++)
        {
            Thread newThread = new Thread(new ThreadStart(Listeners));
            newThread.Start();
        }
    }
}
