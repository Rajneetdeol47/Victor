﻿
namespace WingtipToys.Account
{


    public partial class Manage
    {
        protected global::System.Web.UI.WebControls.PlaceHolder successMessage;

        protected global::System.Web.UI.WebControls.PlaceHolder changePasswordHolder;

        protected global::System.Web.UI.WebControls.Label CurrentPasswordLabel;

        protected global::System.Web.UI.WebControls.TextBox CurrentPassword;

        protected global::System.Web.UI.WebControls.Label NewPasswordLabel;

        protected global::System.Web.UI.WebControls.TextBox NewPassword;

        protected global::System.Web.UI.WebControls.Label ConfirmNewPasswordLabel;

        protected global::System.Web.UI.WebControls.TextBox ConfirmNewPassword;
    }
}
