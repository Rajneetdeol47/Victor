﻿
namespace WingtipToys
{


  public partial class AddToCart
  {

    protected global::System.Web.UI.HtmlControls.HtmlForm form1;
  }
}
