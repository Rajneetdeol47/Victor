﻿
namespace WingtipToys {
    
    
    public partial class ProductDetails {
        
        protected global::System.Web.UI.WebControls.FormView productDetail;
    }
}
