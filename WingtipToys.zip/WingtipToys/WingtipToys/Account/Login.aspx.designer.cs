﻿
namespace WingtipToys.Account
{


    public partial class Login
    {

        protected global::System.Web.UI.WebControls.PlaceHolder ErrorMessage;

        protected global::System.Web.UI.WebControls.Literal FailureText;

        protected global::System.Web.UI.WebControls.TextBox UserName;

        protected global::System.Web.UI.WebControls.TextBox Password;

        protected global::System.Web.UI.WebControls.CheckBox RememberMe;

        protected global::System.Web.UI.WebControls.HyperLink RegisterHyperLink;
    }
}
