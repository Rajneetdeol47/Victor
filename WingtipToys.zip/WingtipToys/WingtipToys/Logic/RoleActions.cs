﻿using WingtipToys.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;

namespace WingtipToys.Logic
{
    internal class RoleActions
  {
    internal void createAdmin()
    {
      // Access the app context and create result variables.
      Models.ApplicationDbContext context = new ApplicationDbContext();
      IdentityResult IdRoleResult;
      IdentityResult IdUserResult;

      // RoleStore object by using the ApplicationDbContext object. 
      var roleStore = new RoleStore<IdentityRole>(context);

      // RoleManager, only allowed to contain IdentityRole objects. 
      var roleMgr = new RoleManager<IdentityRole>(roleStore);

      // Administrator role if it doesn't already exist.
      if (!roleMgr.RoleExists("Administrator"))
      {
        IdRoleResult = roleMgr.Create(new IdentityRole("Administrator"));
        if (!IdRoleResult.Succeeded)
        {
          //exception
        }
      }

      //UserManager object based on the UserStore object and DbContext  
      var userMgr = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
      var appUser = new ApplicationUser()
      {
        UserName = "Admin",
      };
      IdUserResult = userMgr.Create(appUser, "Pa$$word");

      if (IdUserResult.Succeeded)
      {
        IdUserResult = userMgr.AddToRole(appUser.Id, "Administrator");
        if (!IdUserResult.Succeeded)
        {
          //exception
        }
      }
      else
      {
        //exception
      }
    }
  }
}