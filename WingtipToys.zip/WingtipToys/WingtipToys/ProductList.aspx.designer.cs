﻿
namespace WingtipToys {
    
    
    public partial class ProductList {
        
        protected global::System.Web.UI.WebControls.ListView productList;
    }
}
