﻿
namespace WingtipToys {
    
    
    public partial class ErrorPage {
        
        protected global::System.Web.UI.WebControls.Label FriendlyErrorMsg;
        
        protected global::System.Web.UI.WebControls.Panel DetailedErrorPanel;
        
        protected global::System.Web.UI.WebControls.Label ErrorDetailedMsg;
        
        protected global::System.Web.UI.WebControls.Label ErrorHandler;
        
        protected global::System.Web.UI.WebControls.Label InnerMessage;
        
        protected global::System.Web.UI.WebControls.Label InnerTrace;
    }
}
