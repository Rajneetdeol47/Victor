﻿
namespace WingtipToys
{


    public partial class ShoppingCart
    {

        protected global::System.Web.UI.HtmlControls.HtmlGenericControl ShoppingCartTitle;

        protected global::System.Web.UI.WebControls.GridView CartList;

        protected global::System.Web.UI.WebControls.Label LabelTotalText;

        protected global::System.Web.UI.WebControls.Label lblTotal;

        protected global::System.Web.UI.WebControls.Button UpdateBtn;
    }
}
