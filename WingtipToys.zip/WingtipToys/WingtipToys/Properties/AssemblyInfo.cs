﻿using System.Reflection;
using System.Runtime.InteropServices;

// set of attributes
// associated with an assembly.
[assembly: AssemblyTitle("WingtipToys")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("WingtipToys")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("99f99c13-50a3-4da1-b858-0c0cb9afa2ee")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
