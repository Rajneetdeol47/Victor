﻿
namespace WingtipToys
{


  public partial class _Default
  {
  }
}
