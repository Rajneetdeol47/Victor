﻿
namespace WingtipToys.Admin {
    
    
    public partial class AdminPage {
        
        protected global::System.Web.UI.WebControls.Label LabelAddCategory;
        
        protected global::System.Web.UI.WebControls.DropDownList DropDownAddCategory;
        
        protected global::System.Web.UI.WebControls.Label LabelAddName;
        
        protected global::System.Web.UI.WebControls.TextBox AddProductName;
        
        protected global::System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
        
        protected global::System.Web.UI.WebControls.Label LabelAddDescription;
        
        protected global::System.Web.UI.WebControls.TextBox AddProductDescription;
        
        protected global::System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator2;
        
        protected global::System.Web.UI.WebControls.Label LabelAddPrice;
        
        protected global::System.Web.UI.WebControls.TextBox AddProductPrice;
        
        protected global::System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator3;
        
        protected global::System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
        
        protected global::System.Web.UI.WebControls.Label LabelAddImageFile;
        
        protected global::System.Web.UI.WebControls.FileUpload ProductImage;
        
        protected global::System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator4;
        
        protected global::System.Web.UI.WebControls.Button AddProductButton;
        
        protected global::System.Web.UI.WebControls.Label LabelAddStatus;
        
        protected global::System.Web.UI.WebControls.Label LabelRemoveProduct;
        
        protected global::System.Web.UI.WebControls.DropDownList DropDownRemoveProduct;
        
        protected global::System.Web.UI.WebControls.Button RemoveProductButton;
        
        protected global::System.Web.UI.WebControls.Label LabelRemoveStatus;
    }
}
