﻿
namespace WingtipToys.Account {
    
    
    public partial class Register {
        
        protected global::System.Web.UI.WebControls.Literal ErrorMessage;
        
        protected global::System.Web.UI.WebControls.TextBox UserName;
        
        protected global::System.Web.UI.WebControls.TextBox Password;
        
        protected global::System.Web.UI.WebControls.TextBox ConfirmPassword;
    }
}
